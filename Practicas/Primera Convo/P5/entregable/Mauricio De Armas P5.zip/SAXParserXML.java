/* XMLParser imports */
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import org.xml.sax.InputSource;
import org.xml.sax.ext.LexicalHandler;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.apache.xerces.parsers.SAXParser;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
/* JATSValidatorErrorHandler imports */
import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXParseException;
/* XMLLocator imports */
import java.util.Stack;
/* JATSHandler imports */
import org.xml.sax.Locator;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;


public class SAXParserXML {
    public void parse(String uri, Boolean validation ) {
        System.out.println("Analizando el fichero: " + uri + "\n\n");
        XMLReader parser;
        final MyContent_LexicalHandler handler = new MyContent_LexicalHandler();

        try {
            // instanciar el analizador (parser)
            parser = new SAXParser();
            // analizar el documento
            parser.parse(uri);
            parser.setProperty("http://xml.org/sax/properties/lexical-handler", handler);
            parser.setContentHandler(handler);
            if (validation) {
                parser.setFeature("http://xml.org/sax/features/validation", true);
                parser.setErrorHandler(new JATSValidatorErrorHandler());
            } else {
                parser.setFeature("http://apache.org/xml/features/nonvalidating/load-dtd-grammar", false);
                parser.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
            }

            InputSource inputSource = new InputSource();
            inputSource.setCharacterStream(new InputStreamReader(new FileInputStream(new File(uri))));
            parser.parse(inputSource);

        } catch (IOException e) {
            System.out.println("Error al leer URI: " + e.getMessage());
        } catch (SAXNotRecognizedException ex) {
            System.out.println("Error analizando: " + ex.getMessage());
        }catch (SAXNotSupportedException ex) {
            System.err.println("SAX no puedo realizar la operacion requerida" + ex.getMessage());
            throw new RuntimeException("SAX no puedo realizar la operacion requerida", ex);
        }catch (SAXException ex) {
            System.err.println("Parsing error: " + ex.getMessage());
            throw new RuntimeException("Parsing error", ex);
        }
    }
    public static void main(String[] args) {
        if ( args.length != 1 ) {
            System.exit(0);
            
        }
        String uri = args[0];
        SAXParserXML parserDemo = new SAXParserXML();
        parserDemo.parse(args[0], args.length == 2 && args[1] != null && !args[1].equals(""));
    }
}


/**
 * El XML validation error handler.
 * Usado cuando la validacion está activa.
 */
class JATSValidatorErrorHandler implements ErrorHandler {

    /**
     * Enseña mensje de warning.
     *
     * @param exception Excepcion de validacion.
     */
    public void warning (SAXParseException exception) {
        System.err.println("------ VALIDATION WARNING ------");
        System.err.println(exception.getMessage());
        System.err.println("--------------------------------");
    }

    /**
     * Enseña mensaje de error.
     *
     * @param exception Excepcion de validacion.
     */
    public void error (SAXParseException exception) {
        System.err.println("------ VALIDATION ERROR ------");
        System.err.println(exception.getMessage());
        System.err.println("------------------------------");
    }

    /**
     * Enseña mensaje de error fatal.
     *
     * @param exception Excepcion de validacion.
     */
    public void fatalError (SAXParseException exception) {
        System.err.println("------ VALIDATION FATAL ERROR ------");
        System.err.println(exception.getMessage());
        System.err.println("------------------------------------");
    }
}

/**
 * El handler lexico y de contenido de un archivo XML.
 * Se obtendrá como uoutput la siguiente informacion:
 * - el número de instrucciones de procesado.
 * - la instrucción de procesado con datos más largos.
 * - el número de etiquetas de cierre, se contarán todas
 *   incluidas las de los elementos vacíos comprimidos.
 * - el nombre de etiqueta más largo.
 * - el número de elementos vacíos
 *   Se contarán como elementos vacíos tanto los que 
 *   aparecen de forma comprimida como los que tienen 
 *   una etiqueta de inicio, seguido de una etiqueta
 *   de fin, pero sin contenido.
 * - el número de secciones CDATA.
 * - el nombre de la etiqueta con mayor número de atributos
 *   y el número de dichos atributos.
 * - el nombre del atributo con valor más corto y su valor.
 */

class MyContent_LexicalHandler implements ContentHandler, LexicalHandler {
    /**
     * Variables de enteros para manejo de numero de objetos requeridos.
     */
    private int numInstrucc, closeL, emptyEl, cdata, atrr, auxLabel,auxDataLabel;
    /**
     * Variables de Strings para manejo de objetos requeridos.
     */
    private String pi="", label="", atrrLabel="", valueAtrrCorto, atrrCorto, labelAtrrCorto;
    /**
     * Locator.
     */
    private Locator locator;
    /**
     * Stack quer guarda labels para saber en que label está.
     */
    private final Stack<String> position = new Stack<>();


    /**
     * Termina el parseo y enseña resultados.
     */
    public void endDocument() throws SAXException {
        System.err.println("- Instrucciones de procesado: "+this.numInstrucc);
        System.err.println("- La PI con datos más largos fue: "+this.pi);
        System.err.println("- Etiquetas de cierre: "+this.closeL);
        System.err.println("- Etiqueta de nombre más largo: "+this.label+".");
        System.err.println("- Elementos vacíos: "+this.emptyEl);
        System.err.println("- Secciones CDATA: "+this.cdata);
        System.err.println("- La etiqueta \""+this.atrrLabel+"\" tenía "+this.atrr+" atributos.");
        System.err.println("- El valor más corto de atributo ha sido \""+this.valueAtrrCorto+"\" y lo ha tenido el atributo \""+this.atrrCorto+"\" de la etiqueta \""+this.labelAtrrCorto+"\".");

    }
    /**
     * Procesa una intruccion del documento XML.
     * 
     * @param target Nombre de la instruccion
     * 
     * @param data Valor de la instruccion.
     */
    public void processingInstruction(String target, String data) { 
            this.numInstrucc++;

            if(this.auxDataLabel<data.length()){
                this.pi=target;
                this.auxDataLabel=data.length();
            }

    }
    /**
     * Parsea la tag de comienzo de un elemento.
     *
     * @param uri El numbre URI, o un string vacio si no hay URI o no ha sido ejecutado.
     * 
     * @param localName nombre local sin prefijo, o un string vacio
     *        si no ha sido ejecutado.
     * @param qName nombre calificado con prefijo, o un string vacio
     *        si los nombres calificados non están disponibles.
     * @param atts Los atributos del elemento.
     */
    public void startElement(String namespaceURI, String localName, String qName, Attributes atts) throws SAXException { 
        this.position.push(localName);
        if(qName.length() > this.label.length()){
            this.label=qName;
        }
        if(atts.getLength()> this.atrr){
            this.atrr = atts.getLength();
            this.atrrLabel = qName;
        }
        String value;
        for(int i =0; i<atts.getLength();i++){
             value = atts.getValue(i);
            
            if(this.valueAtrrCorto == null){
                this.valueAtrrCorto=value;
                this.labelAtrrCorto=qName;
                this.atrrCorto = atts.getQName(i); 
            }
            if(value.length() < this.valueAtrrCorto.length() && this.valueAtrrCorto != null){
                this.valueAtrrCorto=value;
                this.labelAtrrCorto=qName;
                this.atrrCorto = atts.getQName(i);
            }

        }

        

    }
    /**
     * Parsea la tag de final de un elemento.
     *
     * @param uri El numbre URI, o un string vacio si no hay URI o no ha sido ejecutado.
     * 
     * @param localName nombre local sin prefijo, o un string vacio
     *        si no ha sido ejecutado.
     * @param qName nombre calificado con prefijo, o un string vacio
     *        si los nombres calificados non están disponibles.
     * @param atts Los atributos del elemento.
     */
    public void endElement(String namespaceURI, String localName, String qName) throws SAXException {
        this.closeL++;
        String n = this.position.pop();
        if(n == localName){
            this.emptyEl++;
        }
        if(n == "char"){
            while (n != localName){
                n = this.position.pop();
            }
        }



     }
     /**
     * Parsea un caracter dentro de una tag.
     *
     * @param ch Los caracteres del documento XML.
     * @param start La posicion inicial en el array.
     * @param length El numero de caracteres a leer del array.
     */
    public void characters(char[] ch, int start, int end){
        this.position.push("char");
    }

    /**
     * Empieza el parseo del CDATA.
     */

    public void startCDATA(){ 
        this.cdata++;
    }

    /* Metodos sin usar. */
    public void setDocumentLocator(Locator locator) { }
    public void startDocument() throws SAXException { }
    public void startPrefixMapping(String prefix, String uri) {}
    public void endPrefixMapping(String prefix) {}
    public void ignorableWhitespace(char[] ch, int start, int end) {}
    public void skippedEntity(String name) throws SAXException {}
    public void comment(char[] ch, int start, int length) {}
    public void endCDATA(){}
    public void endDTD(){}
    public void endEntity(String name){}
    public void startDTD(String name, String publicId, String systemId){}
    public void startEntity(String name){}
}

